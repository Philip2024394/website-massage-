// Entry point for Appwrite Function
export { default } from './src/main.js'